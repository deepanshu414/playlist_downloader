import os
import psutil
import argparse

def find_file_path(file_name, search_list=False):
    a = 0
    list_main = []
    
    def get_drive_names():
        try:
            drives = []
            for partition in psutil.disk_partitions():
                drives.append(partition.device)
            return drives
        except Exception as e:
            print("Error: " + str(e))
            return []

    drive_names = get_drive_names()
    for drive in drive_names:
        for root, dirs, files in os.walk(drive):
            for file in files:
                if file_name in file:
                    file_path = os.path.join(root, file)
                    if search_list:
                        list_main.append(file_path)
                    else:
                        print(file_path)
                    a += 1
    
    if a == 0:
        if search_list:
            list_main.append("None")
        else:
            print(f"No files found with the name '{file_name}' in any drive.")
    else:
        if not search_list:
            print(f"Total number of files : {a}")

    return list_main

# def main():
parser = argparse.ArgumentParser(description="Search for files across all drives.")
parser.add_argument('search_term', type=str, help="The name or part of the name of the file to search for.")
parser.add_argument('--list', action='store_true', help="List all file paths instead of just printing them.")

args = parser.parse_args()

if args.list:
    result = find_file_path(args.search_term, search_list=True)
    print(result)
else:
    find_file_path(args.search_term)

# if __name__ == "__main__":
#     main()
